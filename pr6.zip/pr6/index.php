<?php
session_start();
$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_Samokrutov364') or die('Ошибка подключения к базе данных');
$db->set_charset('utf8');
$category = '';
$minPrice = '';
$maxPrice = '';
$searchName = '';
$article = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category = $_POST['category'];
    $minPrice = $_POST['min_price'];
    $maxPrice = $_POST['max_price'];
    $searchName = $_POST['search_name'];
    $article = $_POST['article']; // Исправлено здесь
}
$sql = "SELECT * FROM products WHERE 1=1";
if(!empty($category)) {
    $sql .= " AND category = '" . $db->real_escape_string($category) . "'";
}
if(!empty($minPrice)) {
    $sql .= " AND price >= " . (float)$minPrice;
}
if(!empty($maxPrice)) {
    $sql .= " AND price <= " . (float)$maxPrice;
}
if(!empty($searchName)) {
    $sql .= " AND name LIKE '%" . $db->real_escape_string($searchName) . "%'";
}
if(!empty($article)) {
    $sql .= " AND article LIKE '%" . $db->real_escape_string($article) . "%'"; // Используйте правильное поле
}
$result = $db->query($sql);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<h1>Фильтрация</h1>
<form method="post" action="">
    <label for="category">Категория:</label>
    <select name="category" id="category">
        <option value="">Все</option>
        <option value="Диваны" <?= $category == 'Диваны' ? 'selected' : '' ?>>Диваны</option>
        <option value="Стулья" <?= $category == 'Стулья' ? 'selected' : '' ?>>Стулья</option>
        <option value="Столы" <?= $category == 'Столы' ? 'selected' : '' ?>>Столы</option>
    </select>
    <label for="min_price">Минимальная цена:</label>
    <input type="number" name="min_price" id="min_price" value="<?= htmlspecialchars($minPrice) ?>">
    <label for="max_price">Максимальная цена:</label>
    <input type="number" name="max_price" id="max_price" value="<?= htmlspecialchars($maxPrice) ?>">
    <label for="search_name">Поиск по имени:</label>
    <input type="text" name="search_name" id="search_name" value="<?= htmlspecialchars($searchName) ?>">
    <label for="article">Поиск по артикулу:</label> <!-- Исправлено здесь -->
    <input type="text" name="article" id="article" value="<?= htmlspecialchars($article) ?>"> <!-- Исправлено здесь -->
    <button type="submit">Искать</button>
</form>
<h2>Товары</h2>
<table>
    <tr>
        <th>Название</th>
        <th>Категория</th>
        <th>Цена</th>
        <th>Арт.</th>
    </tr>
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['category']) ?></td>
                <td><?= htmlspecialchars($row['price']) ?></td>
                <td><?= htmlspecialchars($row['article']) ?></td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="4">Нет товаров, соответствующих фильтрам.</td>
        </tr>
    <?php endif; ?>
</table>

<?php
$db->close();
?>
</body>
</html>